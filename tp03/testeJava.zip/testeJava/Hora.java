import java.util.InputMismatchException;
import java.util.Scanner;

public class Hora {
    // Atributos
    private int hora;
    private int min;
    private int seg;

    // Construtor interativo
    public Hora() {
        setHor();
        setMin();
        setSeg();
    }

    // Setters
    public void setHor() {
        this.hora = lerEntradaValida("Digite a hora (0-23): ", 0, 23);
    }

    public void setMin() {
        this.min = lerEntradaValida("Digite os minutos (0-59): ", 0, 59);
    }

    public void setSeg() {
        this.seg = lerEntradaValida("Digite os segundos (0-59): ", 0, 59);
    }

    // Getters
    public int getHor() {
        return this.hora;
    }

    public int getMin() {
        return this.min;
    }

    public int getSeg() {
        return this.seg;
    }

    // Formatação: hh:mm:ss
    public String getHoral() {
        return String.format("%02d:%02d:%02d", this.hora, this.min, this.seg);
    }

    // Formatação: hh:mm:ss (AM/PM)
    public String getHora2() {
        String periodo = (this.hora < 12) ? "AM" : "PM";
        int horaFormato12 = (this.hora == 0 || this.hora == 12) ? 12 : this.hora % 12;
        
        return String.format("%02d:%02d:%02d (%s)", horaFormato12, this.min, this.seg, periodo);
    }

    // Quantidade total de segundos
    public int getSegundos() {
        return (this.hora * 3600) + (this.min * 60) + this.seg;
    }

    // Método auxiliar para consistência de dados e tratamento de exceção
    private int lerEntradaValida(String mensagem, int minVal, int maxVal) {
        Scanner scanner = new Scanner(System.in);
        int valor = -1;
        boolean valido = false;

        while (!valido) {
            try {
                System.out.print(mensagem);
                valor = scanner.nextInt();
                
                if (valor >= minVal && valor <= maxVal) {
                    valido = true;
                } else {
                    System.out.println("Valor fora do intervalo permitido. Tente novamente.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida! Por favor, digite um número inteiro.");
                scanner.nextLine(); 
            }
        }
        return valor;
    }
}