public class TesteHora {
    public static void main(String[] args) {
        System.out.println("Construtor Interativo");
        // O construtor sem parâmetros invocará os setters interativos (setHor(), setMin(), setSeg())
        Hora horaInterativa = new Hora();
        
        System.out.println("\nResumo da Hora Interativa:");
        System.out.println("Formato 1 (24h): " + horaInterativa.getHoral());
        System.out.println("Formato 2 (AM/PM): " + horaInterativa.getHora2());
        System.out.println("Total em segundos: " + horaInterativa.getSegundos());
    }
}